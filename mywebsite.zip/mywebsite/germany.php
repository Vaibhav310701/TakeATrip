<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/aus.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
</head>
<body>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>

<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>



<div class="container-fluid">
  <div class="jumbotron">
<h1>Germany</h1>
<div style="font-family:'Licorice', cursive;">
<h4>
Factors of tourist interest
</h4>
</div>
<div style="font-family:'Licorice', cursive; overflow: scroll; height: 300px;">
<h5>Health</h5><br>
<p> About 242 million nights, or two-thirds of all nights spent in hotels in Germany, are spent in spa towns.[10] Germany is well known for health tourism, with many of the numerous spa towns having been established at a hot spring, offering convalescence (German: Kur) or preventive care by means of mineral water and/or other spa treatment. Spa towns and seaside resorts carry official designations such as Mineral and mud spas (Mineral- und Moorbäder), Healthy climate resorts (Heilklimatische Kurorte), Kneipp cure resorts (Kneippkurorte = water therapy resorts), Seaside resorts (Seebäder), Climatic resorts (Luftkurorte), and Recreation resorts (Erholungsorte). The largest and most well known resorts also have casinos, most notably at Bad Wiessee, Baden-Baden (Kurhaus), Wiesbaden (Kurhaus), Aachen, Travemünde and Westerland (Kurhaus).<br><br>
<h5>Regions</h5><br>
The most visited tourist regions in Germany are the East Frisian and North Frisian Islands, the Baltic Sea coasts of Holstein, Mecklenburg and Vorpommern, the Rhine Valley, the Bavarian and Black Forest, and the Bavarian Alps.<br><br>
<h5>Theme routes</h5><br>
Since the 1930s, local and regional governments have set up various theme routes, to help visitors get to know a specific region and its cultural or scenic qualities. The table below shows some of the most prominent theme routes. Other popular German theme routes include parts of the European Route of Brick Gothic and European Route of Industrial Heritage, the Harz-Heide Road, Bertha Benz Memorial Route and Bergstrasse.<br><br>
<h5>Winter sport</h5><br>
The main winter sport regions in Germany are the Bavarian Alps and Northern Limestone Alps, as well as the Ore Mountains, Harz Mountains, Fichtel Mountains and Bavarian Forest within the Central Uplands. First class winter sport infrastructure is available for alpine skiing and snowboarding, bobsledding and cross-country skiing.
In most regions, winter sports are limited to the winter months November to February. During the Advent season, many German towns and cities host Christmas markets

</p>
</p>
</div>
  </div>
  
  <div class="row gallery">
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A8.jpg">
        <img class="img-fluid"src="images\Australia\A8.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A7.jpg">
        <img class="img-fluid"src="images\Australia\A7.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A1.jpg">
        <img class="img-fluid"src="images\Australia\A1.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A2.jpg">
        <img class="img-fluid"src="images\Australia\A2.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A3.jpg">
        <img class="img-fluid"src="images\Australia\A3.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A4.jpg">
        <img class="img-fluid"src="images\Australia\A4.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A5.jpg">
        <img class="img-fluid"src="images\Australia\A5.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A6.jpg">
        <img class="img-fluid"src="images\Australia\A6.jpg">
      </a>
    </div>
  </div>
</div>
<section>
<div class="Message">
  <div class="py-4">
    <h4><marquee behavior="scroll" direction="right" scrollamount="12" background="black"><u>Get the Best Holiday Planned by Experts!</u></marquee></h3>
  </div>
</div>

<div class="container">
   <form action="userinfo.php" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">Username</label>
      </div>
      <div class="col-75">
        <input type="text" id="username" name="user" required="required" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" required="required" placeholder="Enter your mail..">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="mobile">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mobile" name="mobile" required="required" placeholder="Enter your mobile no..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
     <input type="text" id="country" name="country" required="required" placeholder="Enter the  country name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Comment">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="comment" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<div class="footertext">
<footer>
    <p>©2021 Take A Trip All Rights Reserved.</p>
</footer>
</div>


</body>
</html>