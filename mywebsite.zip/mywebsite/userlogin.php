 <?php

$con = mysqli_connect('localhost','root');

$username=$password='';
mysqli_select_db($con, 'usersignup');


$username = $_POST['username'];
$password = $_POST['password'];

$query= "select * from signintable where username = '{$username}'";
$select_user_query = mysqli_query($con,$query);
if(!$select_user_query){

	die("QUERY FAILED".mysql_error($con));

}
while ($row = mysqli_fetch_array($select_user_query)){

	$db_username=$row['username'];
	$db_password=$row["password"];

}
if($username !== $db_username && $password !== $db_password){
	header("Location:login.php");
}
else if($username == $db_username && $password == $db_password){
	header("Location:index.php");
}
else{
	header("Location:login.php");
}
?>