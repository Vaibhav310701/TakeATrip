<?php
$username=$email=$comment='';
$con = mysqli_connect('localhost','root');
if ($con) {
	echo "Connection Successfull";
}
else {
	echo("No Connection");
}
mysqli_select_db($con, 'userfeedback');

$username = $_POST['username'];
$email = $_POST['email'];
$comment = $_POST['comment'];

$query = "insert into feedbackuser( username,email,comment) values ('$username','$email','$comment')";
echo "$query";
mysqli_query($con,$query);
header("Location:feedback.html")
?>