<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/aus.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
</head>
<body>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>

<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>


<div class="container-fluid">
  <div class="jumbotron">
<h1>India</h1>
<div style="font-family:'Licorice', cursive;">
<h4>Destinations<h4>
</div>
<div style="font-family:'Licorice', cursive; overflow: scroll; height: 300px;">
<p>
<h5>Adventure tourism</h5><br>
As a kind of tourism in India, adventure tourism has recently grown in India. This involves exploration of remote areas and exotic locales and engaging in various activities. For adventure tourism in India, tourists prefer to go for trekking to places like Ladakh, Sikkim, and Himalaya. Himachal Pradesh and Jammu and Kashmir are popular for the skiing facilities they offer. Whitewater rafting is also catching on in India and tourists flock to places such as Uttranchal, Assam, and Arunachal Pradesh for this adrenalin-packed activity.<br><br>
<h5>Beach Tourism</h5><br>
India’s vast coastline and islands provides ample opportunities for fun packed tourism. Kerala, Goa, Andaman & Nicobar Islands, Lakshadweep islands attract tourists in large numbers all around the year.
<h5>Cultural tourism</h5><br>
India is known for its rich cultural heritage and an element of mysticism, which is why tourists come to India to experience it for themselves. The various fairs and festivals that tourists can visit in India are the Pushkar fair (Rajasthan), Taj Mahotsav (Uttar Pradesh), and Suraj Kund mela (Haryana). Sites like Ajanta & Ellora caves (Maharshtra), Mahabalipuram (TamilNadu), Hampi (Karnataka), Taj Mahal (Uttar Pradesh), Hawa Mahal (Rajasthan).<br><br>
<h5>Eco tourism</h5><br>
Among the types of tourism in India, ecotourism have grown recently. Ecotourism entails the sustainable preservation of a naturally endowed area or region. This is becoming more and more significant for the ecological development of all regions that have tourist value. For ecotourism in India, tourists can go to places such as Kaziranga National Park (Assam), Gir National Park (Gujarat), and Kanha National Park (Madhya Pradesh).<br><br>
<h5>Medical tourism</h5><br>
Tourists from all over the world have been thronging India to avail themselves of cost-effective but superior quality healthcare in terms of surgical procedures and general medical attention. There are several medical institutes in the country that cater to foreign patients and impart top-quality healthcare at a fraction of what it would have cost in developed nations such as USA and UK. The city of Chennai (Tamil Nadu) attracts around 45% of medical tourists from foreign countries.<br><br>
<h5>Wildlife tourism</h5><br>
India has a rich forest cover which has some beautiful and exotic species of wildlife – some of which that are even endangered and very rare. This has boosted wildlife tourism in India. The places where a foreign tourist can go for wildlife tourism in India are the Sariska Wildlife Sanctuary, Keoladeo Ghana National Park (Rajasthan), and Corbett National Park (Uttarkhand).<br><br>
</p>
</p>
</div>
  </div>
  
  <div class="row gallery">
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A8.jpg">
        <img class="img-fluid"src="images\Australia\A8.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A7.jpg">
        <img class="img-fluid"src="images\Australia\A7.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A1.jpg">
        <img class="img-fluid"src="images\Australia\A1.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A2.jpg">
        <img class="img-fluid"src="images\Australia\A2.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A3.jpg">
        <img class="img-fluid"src="images\Australia\A3.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A4.jpg">
        <img class="img-fluid"src="images\Australia\A4.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A5.jpg">
        <img class="img-fluid"src="images\Australia\A5.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A6.jpg">
        <img class="img-fluid"src="images\Australia\A6.jpg">
      </a>
    </div>
  </div>
</div>
<section>
<div class="Message">
  <div class="py-4">
    <h4><marquee behavior="scroll" direction="right" scrollamount="12" background="black"><u>Get the Best Holiday Planned by Experts!</u></marquee></h3>
  </div>
</div>

<div class="container">
   <form action="userinfo.php" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">Username</label>
      </div>
      <div class="col-75">
        <input type="text" id="username" name="user" required="required" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" required="required" placeholder="Enter your mail..">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="mobile">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mobile" name="mobile" required="required" placeholder="Enter your mobile no..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
     <input type="text" id="country" name="country" required="required" placeholder="Enter the  country name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Comment">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="comment"  placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>

</body>
</html>
