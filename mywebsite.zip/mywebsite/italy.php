<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/aus.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
</head>
<body>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>

<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>


<div class="container-fluid">
  <div class="jumbotron">
<h1>Italy</h1>
<div style="font-family:'Licorice', cursive;">
<h4>
Factors of tourist interest
</h4>
</div>
<div style="font-family:'Licorice', cursive; overflow: scroll; height: 300px;">
<h5>Artistic-cultural tourism</h5>
<p>Italy has a vast and important historical-architectural heritage,[28] both in terms of the quantity of artefacts, as well as in terms of conservation, and in terms of intrinsic artistic-cultural value. For example, Italy boasts the largest number of sites indicated in the UNESCO World Heritage List.[29]
In general, the Italian cultural heritage is the largest in the world since it consists of 60% to 75% of all the artistic assets that exist on each continent,[10] with over 4,000 museums, 6,000 archaeological sites, 85,000 historic churches and 40,000 historic palaces, all subject to protection by the Italian Ministry of Culture.[11] In 2013, the value of the artistic and cultural heritage alone was estimated at 5.4% of Italian GDP, approximately €75.5 billion, capable of employing approximately 1.4 million workers.According to the Eurostat report of 2019, Italian tourism is first in Europe in terms of the number of jobs generated (4.2 million) and third for the average visitor expenditure and the share of revenues of the national sector compared to the European total (€48 billion, 12% of the total).<br><br>
<h5>Seaside and lake tourism</h5><br>
The coastal development of the Italian peninsula extends along at least 8,000 km of shoreline, considering the numerous islands. Beaches and cliffs are dotted with various accommodation facilities, such as bathing establishments, hotels and restaurants, resorts, night and day gathering centers, parks, piers and marinas, as well as numerous historic and artistic centers, which combine interest in the bathing activities to those for leisure, nature and art. There are numerous famous coastal stretches.Lake tourism has been able to establish itself in recent years also due to the sounding board created by some celebrities of the international jet set, well known by the general public.[34] The purchase of a holiday residence along Lake Como by actor George Clooney was very publicized in 2001, as well as the marriage of Tom Cruise and Katie Holmes in 2006 in the Castello Orsini-Odescalchi, along Lake Bracciano.<br><br>
<h5>Winter tourism</h5><br>
Despite a not particularly harsh climate compared to other countries located at more northern latitudes, Italy manages to attract tourists who practice in winter sports due to the presence of numerous mountain ranges (the percentage of mountainous territory is around 35%).[35] Among these are the Alps, the highest mountain range in Europe, and the Apennines, equipped with numerous sports and accommodation facilities. In the north the most famous ski resorts are in the Dolomites and Cortina d'Ampezzo, as well as in the Valle d'Aosta, while in the center-south Abruzzo is the mountainous region with major ski resorts in Roccaraso, Ovindoli, Pescasseroli and Campo Felice.<br><br>
<h5>Religious tourism</h5><br>
There are numerous pilgrimage destinations in Italy, first of all Rome, the residence of the Pope (who is its bishop) and the seat of the Catholic Church. The city is a pilgrimage destination especially during the main events of Catholic religious life, especially during the Jubilees. Although his figure is not officially recognized by the faithful of other Christian denominations, the presence of the Pope in Rome also attracts others, and is an important figure within the Christian creed.[37] In addition to the Holy See, there are numerous pilgrimage sites given by the presence of relics and remains of important figures linked to Christianity, rather than by the memory of events that have occurred that the faithful consider miraculous.
</p>
</p>
</div>
  </div>
  
  <div class="row gallery">
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A8.jpg">
        <img class="img-fluid"src="images\Australia\A8.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A7.jpg">
        <img class="img-fluid"src="images\Australia\A7.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A1.jpg">
        <img class="img-fluid"src="images\Australia\A1.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A2.jpg">
        <img class="img-fluid"src="images\Australia\A2.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A3.jpg">
        <img class="img-fluid"src="images\Australia\A3.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A4.jpg">
        <img class="img-fluid"src="images\Australia\A4.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A5.jpg">
        <img class="img-fluid"src="images\Australia\A5.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A6.jpg">
        <img class="img-fluid"src="images\Australia\A6.jpg">
      </a>
    </div>
  </div>
</div>
<section>
<div class="Message">
  <div class="py-4">
    <h4><marquee behavior="scroll" direction="right" scrollamount="12" background="black"><u>Get the Best Holiday Planned by Experts!</u></marquee></h3>
  </div>
</div>

<div class="container">
  <form action="userinfo.php" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">Username</label>
      </div>
      <div class="col-75">
        <input type="text" id="username" name="user" required="required" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" required="required" placeholder="Enter your mail..">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="mobile">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mobile" name="mobile" required="required" placeholder="Enter your mobile no..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
     <input type="text" id="country" name="country" required="required" placeholder="Enter the  country name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Comment">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="comment" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>


</body>
</html>

