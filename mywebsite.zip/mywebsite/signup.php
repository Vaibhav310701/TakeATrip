 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width , initial-scale=1.0" >
	<title>Sign Up</title>
	<link rel="stylesheet" type="text/css" href="css\sign.css">
	<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
	<script src="https://unpkg.com/scrollreveal"></script>
</head>
<body bgcolor="	#708090	">

<div class="topnav">


  <a href="login.php">Log In</a>
  <a href="signup.php">Sign Up</a>

</div>

<main>
	<section class="wrapper">
		<div class="content">
			<h1 class="main-title">Let's Get Started!</h1>
			<p class="para">Create Your Account!</p>
		</div>
		<div class="container">
			<div class="option">
				<h1 class="con-title">Sign Up</h1>
			<div class="social-media">
				<i class='bx bxl-facebook'></i>
				<i class='bx bxl-google-plus' ></i>
				<i class='bx bxl-twitter' ></i>
			</div>
			<p class="optional">Or</p>
		</div>
		<div class="form-container">
		<form action="usersignup.php" method="post">
			<label for="name">Username</label><br>
			<input type="text" name="username" id="" required="required" placeholder="Enter your Username."><br>
			<label for="password">Password</label><br>
			<input type="password" name="password" id="" required="required" placeholder="Enter your password"><br>	
			<button class= "btn" type="submit">Sign Up</button>
		</form>
	</div>
</div> 
</section>
</main>
<script>
	 ScrollReveal({
	  reset: true ,
    distance: '80px',
    duration:2500,
    delay: 400
	});
ScrollReveal().reveal('.main-title', { delay: 300,origin:'left' });
ScrollReveal().reveal('.form-container', { delay: 1000, origin:'bottom'});
ScrollReveal().reveal('.para', { delay: 600, origin:'right'});
ScrollReveal().reveal('.con-title', { delay: 700, origin:'top'});
ScrollReveal().reveal('.social-media i', { delay: 750, origin:'bottom',interval:200 });
ScrollReveal().reveal('.optional', { delay: 850, origin:'right'});
ScrollReveal().reveal('.btn-con', { delay: 1200, origin:'bottom'});

</script>


</body>
</html>