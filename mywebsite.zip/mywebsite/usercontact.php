<?php
$username=$email=$question='';
$con = mysqli_connect('localhost','root');
if ($con) {
	echo "Connection Successfull";
}
else {
	echo("No Connection");
}
mysqli_select_db($con, 'usercontact');

$username = $_POST['username'];
$email = $_POST['email'];
$question = $_POST['question'];

$query = "insert into contactinfo( username,email,question) values ('$username','$email','$question')";
echo "$query";
mysqli_query($con,$query);
header("Location:contact.html");
?>