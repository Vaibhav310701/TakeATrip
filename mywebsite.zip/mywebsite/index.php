<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>


<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>




 <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
    <li data-target="#demo" data-slide-to="3"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/Dubai/D1.jpg" alt="Dubai" width="1100" height="500">
      <div class="carousel-caption">
       <div style=" color:#fff; text-shadow: 2px 2px 5px red; position: relative; right: 550px; bottom:425px; font-family: 'Licorice', cursive; ">
        <h1><u><b><i>Take A Trip..</i></b></u></h1></div>
        <h3>DUBAI</h3>
        <p>We had such a great time in DUBAI!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/Australia/A1.jpg" alt="Australia" width="1100" height="500">
      <div class="carousel-caption">
          <div style=" color:#fff; text-shadow: 2px 2px 5px red;, 0 0 25px blue, 0 0 5px darkblue; position: relative; right: 550px; bottom:425px; font-family: 'Licorice', cursive; ">
        <h1><u><b><i>Take A Trip..</i></b></u></h1></div>
        <p>We had such a great time in AUSTRALIA!</p>
      </div>   
    </div>
        <div class="carousel-item">
      <img src="images/Italy/I1.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
         <<div style=" color:#fff; text-shadow: 2px 2px 5px red;, 0 0 25px blue, 0 0 5px darkblue; position: relative; right: 550px; bottom:425px; font-family: 'Licorice', cursive; ">
        <h1><u><b><i>Take A Trip..</i></b></u></h1></div>
        <p>We had such a great time in ITALY!</p>
      </div>   
    </div>
     <div class="carousel-item">
      <img src="images/India/IN5.jpg" alt="India" width="1100" height="500">
      <div class="carousel-caption">
          <<div style=" color:#fff; text-shadow: 2px 2px 5px red;, 0 0 25px blue, 0 0 5px darkblue; position: relative; right: 550px; bottom:425px; font-family: 'Licorice', cursive; ">
        <h1><u><b><i>Take A Trip..</i></b></u></h1></div>
        <p>We had such a great time in India!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<section>
  <div class="text-centre">
    <div class="py-4">
    <h2 class="">About Us</h2>
    </div>
  </div>
  <div class="container-fluid">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-12">
      <img src="images/image1.jpg" class="img-fluid aboutimg"> 
    </div>
    <div class="col-lg-6 col-md-6 col-12">
    <h2 class=" textedit display-4">Take A Trip</h2>
    <p>
     Nurtured from the seed of a single great idea - to empower the traveller – Take A Trip is a pioneer in India’s online travel industry. Founded in the year 2021 by Vaibhav Jain and Parag Bhatt, Take A Trip came to life to empower the  traveller with instant bookings and comprehensive choices. The company initiated its journey serving the US-India travel market offering a range of best-value products and services powered by technology and round-the-clock customer support. 
    </p>
    <a href="about.php">More About Us...</a>
    </div>
  </div>
</div>
</section>
<section>
 <div class="service" id="section1">
  <div class="py-4">
    <h2 id="service">Our Services</h2>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <div class="card-a">
  <img class="card-img-top" src="images/Australia/A5.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Australia</h4>
    <p class="card-text">About Australia</p>
    <a href="australia.php" class="btn btn-primary">Check Now</a>
  </div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-12">
        <div class="card-b">
  <img class="card-img-top" src="images/Italy/I2.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Italy</h4>
    <p class="card-text">About Italy</p>
    <a href="italy.php" class="btn btn-primary">Check Now</a>
  </div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-12">
        <div class="card-c">
  <img class="card-img-top" src="images/India/IN2.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">India</h4>
    <p class="card-text">About India</p>
    <a href="india.php" class="btn btn-primary">Check Now</a>
  </div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-12">
        <div class="card-d">
  <img class="card-img-top" src="images/New York/N2.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">New York</h4>
    <p class="card-text">About New York</p>
    <a href="newyork.php" class="btn btn-primary">Check Now</a>
  </div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-12">
        <div class="card-e">
  <img class="card-img-top" src="images/Dubai/D2.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Dubai</h4>
    <p class="card-text">About Dubai</p>
    <a href="dubai.php" class="btn btn-primary">Check Now</a>
  </div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-12">
<div class="card-f">
<img class="card-img-top" src="images/germany/G1.jpg" alt="Card image">
<div class="card-body">
  <h4 class="card-title">Germany</h4>
  <p class="card-text">About Germany</p>
  <a href="germany.php" class="btn btn-primary">Check Now</a>
</div>
</div>
</div>
</div>
</div>
</section>

<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>

<script>
   ScrollReveal({
    reset: true ,
    distance: '80px',
    duration:2500,
    delay: 400
  });
   ScrollReveal().reveal('.text-centre', { delay: 200,origin:'top' });
ScrollReveal().reveal('.service', { delay: 200,origin:'top' });
ScrollReveal().reveal('.card-a', { delay: 300,origin:'left' });
ScrollReveal().reveal('.card-b', { delay: 300,origin:'top' });
ScrollReveal().reveal('.card-c', { delay: 300,origin:'right' });
ScrollReveal().reveal('.card-d', { delay: 300,origin:'left' });
ScrollReveal().reveal('.card-e', { delay: 300,origin:'bottom' });
ScrollReveal().reveal('.card-f', { delay: 300,origin:'right' });
ScrollReveal().reveal('.form-group', { delay: 1000, origin:'bottom'});
ScrollReveal().reveal('.footermsg', { delay: 1100, origin:'bottom'});
</script>

</body> 
</html>