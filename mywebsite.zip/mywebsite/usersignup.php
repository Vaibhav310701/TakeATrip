 <?php

$con = mysqli_connect('localhost','root');
if ($con) {
	echo "Connection Successfull";
}
else {
	echo"No Connection";
}
$username=$password='';
mysqli_select_db($con, 'usersignup');

$username = $_POST['username'];
$password = $_POST['password'];

$s = "select * from signintable where username ='$username'";

$result= mysqli_query($con,$s);

$num=mysqli_num_rows($result);

if($num == 1){
	header('location: signup.php');
}
else{

$query = "insert into signintable (username,password) values ('$username','$password')";

mysqli_query($con,$query);
header('location:login.php');
}

?> 
