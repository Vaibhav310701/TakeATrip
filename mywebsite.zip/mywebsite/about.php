<!DOCTYPE html>
<html lang="en">
<head>
  <title>Take A Trip</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/about.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>
<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>


<div class="jumbotron">
  <h1 class="display-3 main-heading" ><b>TaKe A TrIp</b></h1>
  <div class="myline">
     <p class = "display-4 uspline"><b>it's all about travel...</b></p>
  </div>
</div>

<section>
  <div class="text-centre">
    <div class="py-4">
    <h2 class="">About Us</h2>
    </div>
  </div>
  <div class="container-fluid">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-12">
      <img src="images/image1.jpg" class="img-fluid aboutimg"> 
    </div>
    <div class="col-lg-6 col-md-6 col-12">
    <h2 class=" textedit display-4">Take A Trip</h2>
    <p class="paratext">
     Nurtured from the seed of a single great idea - to empower the traveller – Take A Trip is a pioneer in India’s online travel industry. Founded in the year 2021 by Vaibhav Jain and Parag Bhatt, Take A Trip came to life to empower the  traveller with instant bookings and comprehensive choices. The company initiated its journey serving the US-India travel market offering a range of best-value products and services powered by technology and round-the-clock customer support.<br><br> After consolidating its position in the market as a brand recognised for its reliability and transparency. Take A Trip launched its India operations in 2021. With more and more Indians initiating to transact online with IRCTC and new opportunities with the advent of low cost carriers, Take A Trip offered travellers the convenience of booking travel online with a few clicks.<br><br> Take A Trip rise has been led by the vision and the spirit of each one of its employees, for whom no idea was too big and no problem too difficult. With untiring determination, Take A Trip has proactively diversified its product offering, adding a variety of online and offline products and services. Take A Trip has stayed ahead of the curve by continually evolving its technology to meet the ever-changing demands of the rapidly developing global travel market, steadily establishing itself as India’s leading online travel company.

    </p>
    <a href="about.php">More About Us...</a>
    </div>
  </div>
</div>
</section>

<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>
<script>
   ScrollReveal({
    reset: true ,
    distance: '80px',
    duration:2500,
    delay: 400
  });

ScrollReveal().reveal('.main-heading', { delay: 400, origin:'top',interval:200 });
ScrollReveal().reveal('.uspline', { delay: 400, origin:'bottom',interval:200 });
ScrollReveal().reveal('.aboutimg', { delay: 600, origin:'left',interval:200 });


</script>

</body>
</html>
