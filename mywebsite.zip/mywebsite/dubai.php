<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/aus.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
</head>
<body>
  <div class="container-fluid"></div>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>
<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>



<div class="container-fluid">
  <div class="jumbotron">
<h1>Dubai</h1>
<div style="font-family:'Licorice', cursive;">
<h4>
Factors of tourist interest
</h4>
</div>
<div style="font-family:'Licorice', cursive; overflow: scroll; height: 300px;">
<h5>Attractions</h5><br>
<p>Aspects of Dubai's old culture, while occasionally overshadowed by the boom in economic development, can be found by visiting places around the creek, which splits Dubai into two halves, Bur Dubai and Deira. The buildings lining the Bur Dubai side of the Creek provide the main flavor of the old city. Heritage Village is one of the few remaining parts of historical Dubai, containing preserved buildings. The adjoining Diving Village offers exhibits on pearl diving and fishing. The Diving Village forms part of an ambitious plan to turn the entire "Shindagha" area into a cultural city, recreating life in Dubai as it was in days gone by.Other attractions include the Sheikh Saeed Al Maktoum House; the Dubai Museum in the restored Al Fahidi Fort, which was erected around 1799; and the Heritage Village of Hatta, situated 115 kilometers southeast of Dubai City in the heart of the rocky Hatta Mountains. The history of the village can be traced back 2000 – 3000 years. It consists of 30 buildings, each differing in size, interior layout and building materials used. Great care was taken to use the same materials as those used when originally built during the renovation such as mud, hay, sandalwood and palm fronds. The Sharia Mosque is an old mosque built in the early 19th century using the same building materials and consists of a large prayer hall, a court and courtyard, minaret and other utility rooms.[26] Other museums include the Al Ahmadiya School.<br><br>
<h5>Shopping</h5><br>
Dubai has been nicknamed the "shopping capital of the Middle East."[27][28] The city draws large numbers of shopping tourists from countries within the region and from as far as Eastern Europe, Africa and the Indian Subcontinent. Dubai is known for its souk districts. Souk is the Arabic word for market or place where any kind of goods are brought or exchanged. Traditionally, dhows from the Far East, China, Sri Lanka, and India would discharge their cargo and the goods would be bargained over in the souks adjacent to the docks.[29]

Modern shopping malls and boutiques are also found in the city. Dubai Duty Free at Dubai International Airport offers merchandise catering to the multinational passengers using Dubai International Airport. Outside of Duty Free areas and major sales, Dubai has a reputation for being one of the most expensive shopping destinations in the world.[30]

While boutiques, some electronics shops, department stores and supermarkets may operate on a fixed-price basis, most other outlets consider friendly negotiation as a way of life.

Dubai's numerous shopping centres cater for every consumer's need. Cars, clothing, jewellery, electronics, furnishing, sporting equipment and any other goods will all be likely to be under the same roof.[31]

The Dubai Shopping Festival is a month-long festival held during the month of January each year. During the festival the entire emirate becomes one massive shopping mall. Additionally, the festival brings together music shows, art exhibitions, and folk dances.[32]

The Dubai Summer Surprises (DSS) is the summer version of Dubai Shopping Festival held during June, July and August. Dubai Government launched Dubai Summer Surprises in 1998 in order to promote Dubai as a family holiday destination. DSS offers fun, entertainment, food deals and great offers on shopping.<br><br>
<h5>Cultural sensitivity</h5><br>
Tourists are required to obey some Muslim religious restrictions in public even if they are not Muslim themselves, such as refraining from eating or drinking in public places in the daytime during Ramadan.<br>
Dubai has a modest dress code as part of its criminal law.[34] Sleeveless tops and short dresses are not encouraged at Dubai Mall.[35][36] Clothes are advised to be in appropriate lengths.<br>
Homosexuality is criminalized in Dubai, including for tourists. However, there is a vibrant underground gay scene in Dubai and authorities do not actively search for homosexuals to enforce the law.
</p>
</div
</div>
</div>
  </div>
  
  <div class="row gallery">
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A8.jpg">
        <img class="img-fluid"src="images\Australia\A8.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A7.jpg">
        <img class="img-fluid"src="images\Australia\A7.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A1.jpg">
        <img class="img-fluid"src="images\Australia\A1.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A2.jpg">
        <img class="img-fluid"src="images\Australia\A2.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A3.jpg">
        <img class="img-fluid"src="images\Australia\A3.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A4.jpg">
        <img class="img-fluid"src="images\Australia\A4.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A5.jpg">
        <img class="img-fluid"src="images\Australia\A5.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A6.jpg">
        <img class="img-fluid"src="images\Australia\A6.jpg">
      </a>
    </div>
  </div>
</div>
<section>
<div class="Message">
  <div class="py-4">
    <h4><marquee behavior="scroll" direction="right" scrollamount="12" background="black"><u>Get the Best Holiday Planned by Experts!</u></marquee></h3>
  </div>
</div>

<div class="container">
  <form action="userinfo.php" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">Username</label>
      </div>
      <div class="col-75">
        <input type="text" id="username" name="user" required="required" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" required="required" placeholder="Enter your mail..">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="mobile">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mobile" name="mobile" required="required" placeholder="Enter your mobile no..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
     <input type="text" id="country" name="country" required="required" placeholder="Enter the  country name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Comment">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="comment" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>


</body>
</html>