<?php
$username=$email=$mobile=$country=$Comments='';
$con = mysqli_connect('localhost','root');
if ($con) {
	echo "Connection Successfull";
}
else {
	echo("No Connection");
}
mysqli_select_db($con, 'takeatrip_userdata');

$user = $_POST['user'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$country=$_POST['country'];
$comment = $_POST['comment'];

$query = "insert into userinfodata( user,email,mobile,country,comment ) values ('$user','$email','$mobile','$country','$comment')";
echo "$query";
mysqli_query($con,$query);

?>