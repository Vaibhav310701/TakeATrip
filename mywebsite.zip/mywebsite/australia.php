<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/aus.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
   <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>

<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>

<div class="container-fluid">
  <div class="jumbotron">
<h1>Australia</h1>
<div style="font-family:'Licorice', cursive;">
<h4>Destinations</h4>
</div>
<div style="font-family:'Licorice', cursive; overflow: scroll; height: 300px;">

<p>Hervey Bay is a popular tourist town with ample opportunities for whale watching, although there are plenty of other places along the Australian coastline to see whales.
Fraser Island is considered to be the largest sand island in the world at 1840 km2. It is also Queensland's largest island, and has been inhabited by humans for as much as 5,000 years. The island has rainforests, eucalyptus woodland, mangrove forests, wallum and peat swamps, sand dunes and coastal heaths. The island can be reached by a ferry from River Heads (South of Hervey Bay) to Kingfisher Bay and Wanggoolba Creek or Inskip Point to the north of Rainbow Beach to Hook Point, or by chartered flight from Maroochydore Airport.<br><br><b>Great Barrier Reef</b><br>The Great Barrier Reef attracts up to two million visitors every year.[35] Careful management, which includes permits for camping and all commercial marine tourism within the Great Barrier Reef Marine Park, has so far ensured that tourists have a very minimal impact on the reef.[35] Uluru, Kakadu National Park and Fraser Island are major natural attractions. Uluru won the 2013 Qantas Australian Tourism Awards and was named Australia's best major tourist attraction.<br>
In December 2013, Greg Hunt, the Australian environment minister, approved a plan for dredging to create three shipping terminals as part of the construction of a coal port. According to corresponding approval documents, the process will create around 3 million cubic metres of dredged seabed that will be dumped within the Great Barrier Reef marine park area.<br><br><b>Sydney Opera House</b><br>
Another attraction that appeals to many tourists is the Sydney Opera House. Shopping and casinos are a major drawcard for wealthy Chinese visitors.[38] Wine, indigenous culture and nature tourism also generate travel in Australia.<br><br>
<b>Events</b>
Major events attract a large number of tourists. The Sydney Gay and Lesbian Mardi Gras is an annual event that attractions thousands of international tourists.[39]
The 2000 Sydney Olympics resulted in significant inbound and domestic tourism to Sydney. During the games, Sydney hosted 362,000 domestic and 110,000 international visitors. In addition, up to 4 billion people watched the games worldwide.[40] The 2003 Rugby World Cup attracted 65,000 international visitors to Australia.[40] Schoolies Week is an annual celebration of Year 12 school leavers in late November, many of whom travel to the Gold Coast, where in 2011 they were expected to boost the economy by $60 million

</p>
</p>
</div>
  </div>
  <div class="row gallery">
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A8.jpg" class="wow fadeInUp">
        <img class="img-fluid"src="images\Australia\A8.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A7.jpg">
        <img class="img-fluid"src="images\Australia\A7.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A1.jpg">
        <img class="img-fluid"src="images\Australia\A1.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A2.jpg">
        <img class="img-fluid"src="images\Australia\A2.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A3.jpg">
        <img class="img-fluid"src="images\Australia\A3.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A4.jpg">
        <img class="img-fluid"src="images\Australia\A4.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A5.jpg">
        <img class="img-fluid"src="images\Australia\A5.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A6.jpg">
        <img class="img-fluid"src="images\Australia\A6.jpg">
      </a>
    </div>
  </div>
</div>
</div>
<section>
<div class="Message">
  <div class="py-4">
    <h4><marquee behavior="scroll" direction="right" scrollamount="12" background="black"><u>Get the Best Holiday Planned by Experts!</u></marquee></h3>
  </div>
</div>

<div class="container">
  <form action="userinfo.php" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">Username</label>
      </div>
      <div class="col-75">
        <input type="text" id="username" name="user" required="required" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email"required="required" placeholder="Enter your mail..">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="mobile">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mobile" name="mobile" required="required" placeholder="Enter your mobile no..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
     <input type="text" id="country" name="country" required="required" placeholder="Enter the  country name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Comment">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="comment" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>
</body>
</html>

