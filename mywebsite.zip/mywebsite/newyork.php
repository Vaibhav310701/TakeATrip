<!DOCTYPE html>
<html lang="en">
<head>
  <title>TaKe A TrIp</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/aus.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;1,400&display=swap" rel="stylesheet">
</head>
<body>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}
.topnav a {
  float: right;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
  display: inline-block;
  margin-top: 10px;
  margin-bottom: 10px;
  transition: all 0.4s;
}

.topnav a:hover {
  background-color: #fff;
  color: #000;
}

.topnav a.active {
    color: #000;
    background: #fff;
}

</style>
<div class="topnav">
<a href="logout.php">Logout</a>
 <a href="contact.html">Contact</a>
  <a href="feedback.html">Feedback</a>
  <a href="about.php">About</a>
  <a href="#service">Services</a>
  <a class="active" href="index.php">Home</a>
</div>
<div class="container-fluid">
  <div class="jumbotron">
<h1>New York</h1>
<div style="font-family:'Licorice', cursive;">
<h4>
Factors of tourist interest
</h4>
</div>
<div style="font-family:'Licorice', cursive; overflow: scroll; height: 300px;">
<h5>Special interest tours</h5><br>
<p>New York City Marathon in Harlem with the Duke Ellington Memorial in the background
New York City has a rich musical culture and history.[18] Accordingly, numerous jazz, gospel music, rock and roll, rhythm and blues and hip hop tours are available. Popular locations for music tours include Harlem and the East Village, which is home to several historical sites related to the birth of punk music.[19] Walking tours are one of the most popular ways of seeing the city and many private guides supply tours. Companies producing audio walking tours include the Gesso app.<br>
Food tours are another option for visitors. New York is one of the top culinary destinations in the world. New York's food culture, influenced by the city's immigrants and large number of dining patrons, is diverse. Jewish and Italian immigrants made the city famous for bagels, cheesecake and New York-style pizza. Some 4,000 mobile food vendors, many of them immigrants, are licensed by the city and have made Middle Eastern foods such as falafel and kebabs standbys of contemporary New York street food.[21] The city is also home to many of the finest haute cuisine restaurants in the United States.[22] Food tours allow visitors to try a wide variety of these foods economically and learn about the city's culture.[23] Tour companies include New York Food Tours, Local Finds Queens Food Tours and Rum and Blackbird Tasting Tours.<br>
Visitors to New York City also partake in sports tourism. Sporting events draw tourists to major venues such as the Yankee Stadium, Citi Field, and Madison Square Garden, and to street events such as the New York City Marathon.<br>
Many of these counts also include residents and workers as well. In addition, the actual visitor counts may be greatly inflated since a single person may be counted multiple times if they visited the attraction more than once a year. For this reason, modes of transport such as the Staten Island Ferry and Brooklyn Bridge are excluded, as are neighborhoods such as Greenwich Village, Harlem, and the Financial District.
Brooklyn Bridge Park, which saw 4.62 million visitors in summer 2016, is excluded because annual statistics are not available.[29] However, Coney Island and Rockaway Beach are included since they are seasonal destinations.<br>
The Battery, the port of departure for Statue of Liberty and Ellis Island tourist ferries, is excluded.
Sports stadiums are also excluded since annual attendance may fluctuate greatly from year to year.
</p>
</p>
</div>
  </div>
  
  <div class="row gallery">
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A8.jpg">
        <img class="img-fluid"src="images\Australia\A8.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A7.jpg">
        <img class="img-fluid"src="images\Australia\A7.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A1.jpg">
        <img class="img-fluid"src="images\Australia\A1.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A2.jpg">
        <img class="img-fluid"src="images\Australia\A2.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A3.jpg">
        <img class="img-fluid"src="images\Australia\A3.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A4.jpg">
        <img class="img-fluid"src="images\Australia\A4.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A5.jpg">
        <img class="img-fluid"src="images\Australia\A5.jpg">
      </a>
    </div>
    <div class="col-sm-6 col-md-4 col-lg-3">
      <a href="images\Australia\A6.jpg">
        <img class="img-fluid"src="images\Australia\A6.jpg">
      </a>
    </div>
  </div>
</div>
<section>
<div class="Message">
  <div class="py-4">
    <h4><marquee behavior="scroll" direction="right" scrollamount="12" background="black"><u>Get the Best Holiday Planned by Experts!</u></marquee></h3>
  </div>
</div>

<div class="container">
 <form action="userinfo.php" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">Username</label>
      </div>
      <div class="col-75">
        <input type="text" id="username" name="user" required="required" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" required="required" placeholder="Enter your mail..">
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="mobile">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mobile" name="mobile" required="required" placeholder="Enter your mobile no..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
     <input type="text" id="country" name="country" required="required" placeholder="Enter the  country name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="Comment">Message</label>
      </div>
      <div class="col-75">
        <textarea id="subject" name="comment" placeholder="Write something.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<footer>
  <div class="footertext">
    <p>©2021 Take A Trip All Rights Reserved.</p>
  </div>
</footer>


</body>
</html>